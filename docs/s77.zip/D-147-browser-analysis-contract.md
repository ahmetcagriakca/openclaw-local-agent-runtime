# D-147: Browser Analysis — 3-Mode Observation Contract

- **ID:** D-147
- **Title:** Browser Analysis — 3-Mode Observation Contract
- **Status:** proposed
- **Phase:** S78
- **Date:** 2026-04-06
- **Owner:** AKCA
- **Recommended by:** Claude (architecture analysis) + GPT (cross-review)

-----

## Context

- Vezir frontend (React dashboard, port 3000) kullanılabilirlik analizi yapılmamış.
- Dynamic role selection (D-148) için observation data gerekli — agent neyi seçtiğini, browser'da nerede takıldığını ölçmeden routing kör uçuş olur.
- Claude Code browser destekli analiz yapabiliyor (Claude in Chrome, Playwright, console/network/DOM capture).
- Doğrudan serbest browser mutation açmak gereksiz risk — önce read-only observation layer kurulmalı.
- Usability finding'ler remediation scope'a girdi sağlar.

-----

## Decision

1. **Browser-based analysis 3 modda çalışır:**

| Mode | Scope | Operator Onayı |
|---|---|---|
| `observe_only` | DOM/console/network capture, screenshot, no mutation | Gerekli değil |
| `guided_repro` | Belirli flow'u tekrarla, evidence üret, no mutation | Session başı onay |
| `active_mutation` | Staging-only form fill / click / input | Her mutation öncesi onay |

2. **v1 scope: Sadece `observe_only`.** `guided_repro` ve `active_mutation` sonraki faz.
3. **Her browser analysis session zorunlu evidence artifact'leri üretir.**
4. **Finding'ler severity + reproducibility + owner ile işaretlenir.**
5. **Staging harici mutation yok.** Production URL'e mutation açılamaz.

-----

## Evidence Artifact Standard

Her browser analysis session şu dosyaları üretir:

| Artifact | Format | Description |
|---|---|---|
| `browser-console.txt` | Plain text | Console errors, warnings, logs captured during session |
| `browser-network.txt` | Plain text | Failed requests, slow requests, CORS errors, 4xx/5xx |
| `browser-dom-notes.md` | Markdown | DOM state observations: missing elements, broken layouts, empty states |
| `ux-friction-report.md` | Markdown | Structured finding report (see Finding Schema below) |
| `repro-steps.md` | Markdown | Step-by-step reproduction for each finding |
| `screenshot-evidence/` | PNG | Annotated screenshots per finding |

-----

## Finding Schema

```yaml
finding:
  id: UX-001
  title: "Mission list empty state shows no guidance"
  category: empty_state_quality  # see taxonomy below
  severity: medium               # low / medium / high / critical
  reproducibility: always        # always / intermittent / once
  page: /missions
  repro_steps:
    - Navigate to /missions with no missions created
    - Observe empty page with no CTA or explanation
  expected: Empty state with explanation + create mission CTA
  actual: Blank white area below header
  console_errors: none
  network_errors: none
  screenshot: screenshot-evidence/UX-001.png
  owner: TBD
  status: open
```

-----

## Task Taxonomy

| Category | Description |
|---|---|
| `onboarding_friction` | First-use experience barriers |
| `navigation_confusion` | Unclear routing, dead ends, missing breadcrumbs |
| `approval_flow_friction` | Approval create/decide/expire UX problems |
| `failure_visibility` | Error states hidden, silent failures, missing error messages |
| `empty_state_quality` | Empty/loading/error states missing or unhelpful |
| `latency_perception` | Slow responses without loading indicators, stale data shown |
| `data_quality_display` | Missing/unknown data shown as zero or blank |
| `agent_stuck_vs_user_stuck` | Distinguishing agent-side vs UI-side failure |
| `accessibility` | Keyboard nav, screen reader, contrast, focus management |

-----

## Success Criteria (v1)

| Criterion | Target |
|---|---|
| Verified usability findings | ≥ 5 (net repro ile doğrulanmış) |
| Finding categories covered | ≥ 3 farklı kategori |
| Agent vs user stuck ayrımı | Her finding'de belirtilmiş |
| Evidence artifacts complete | Her session için 6 artifact mevcut |
| Console/network errors documented | Tüm 4xx/5xx ve JS errors listeleniş |

**Not:** GPT 10 finding hedefi önerdi. v1 için 5-7 daha gerçekçi — ilk run'da 10 verified finding scope creep riski taşır.

-----

## Impacted Files

| File | Change |
|---|---|
| `docs/shared/browser-audit-template.md` | New — session template |
| `docs/shared/ux-finding-schema.yaml` | New — finding format definition |
| `evidence/sprint-{N}/browser-audit/` | New — per-sprint browser evidence folder |
| `tools/browser-audit-checklist.sh` | New — optional evidence completeness checker |

-----

## Trade-offs

| + | - |
|---|---|
| Observation data enables informed routing decisions (D-148) | Additional evidence artifact overhead per session |
| Structured finding format enables tracking over time | v1 limited to observe_only — no interactive repro |
| Browser evidence integrates with existing sprint closure model | Requires frontend running on localhost for analysis |
| Taxonomy prevents ad-hoc, unstructured UX complaints | Categories may need expansion after first audit run |

-----

## Rollback / Reversal

- Browser analysis is additive — no existing system modified
- Disabling: simply don't run browser audit sessions
- Evidence artifacts are standalone — removal doesn't affect other sprint evidence

-----

## Dependencies

- D-146 (Azure provider) — audit both providers' agent behavior in browser
- Frontend must be running (port 3000) during analysis sessions
- Claude Code browser capability (Claude in Chrome or Playwright)

-----

## Decision Lifecycle

| Date | Event |
|---|---|
| 2026-04-06 | Proposed by Claude + GPT cross-review |
| TBD | Frozen after operator review |
