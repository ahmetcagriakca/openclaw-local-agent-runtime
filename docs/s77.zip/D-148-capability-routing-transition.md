# D-148: Fixed Role → Capability Routing Transition

- **ID:** D-148
- **Title:** Fixed Role → Capability Routing Transition
- **Status:** proposed
- **Phase:** S79
- **Date:** 2026-04-06
- **Owner:** AKCA
- **Recommended by:** Claude (architecture analysis) + GPT (cross-review)

-----

## Context

- Mevcut sistem 9 sabit rol kullanıyor (`ROLE_REGISTRY`), deterministic routing table ile (D-027), 4-tier complexity router ile (D-032).
- Rol → tool policy → model mapping tamamen statik. Yeni task türleri eklendikçe rol sayısı büyüyecek, bu ölçeklenmez.
- Azure provider (D-146) ve browser analysis (D-147) eklendikten sonra routing kararları daha karmaşık hale gelecek: hangi provider, hangi tool set, browser gerekli mi, risk seviyesi ne.
- Sabit "reviewer", "implementer" gibi label'lar bu karmaşıklığı ifade edemez — capability manifest gerekir.
- Dynamic seçim yapıldıktan sonra "bu seçim iyi miydi?" sorusu ölçülebilir olmalı, yoksa sistem dekoratif.

-----

## Decision

1. **Sabit roller korunur** — kısa vadede silinmez. Role = UX display label + fallback default.
2. **Runtime seçim capability manifest üzerinden yapılır.** Rol adı değil, gerekli capability set'i routing girdisidir.
3. **Yeni mimari:** `Task Intent → Capability Resolver → Provider/Model Selection → Tool Policy Gate → Execution Mode → Verification`
4. **İlk sürümde selection otomatik ama override edilebilir.** Operator her zaman seçimi görebilir: why this provider, why this profile, why this tool set.
5. **Selection quality metric zorunlu.** Ölçüm olmadan dynamic routing açılamaz.

-----

## Capability Axes

| Capability | Type | Description |
|---|---|---|
| `can_code` | bool | Code generation and mutation |
| `can_browser_observe` | bool | Read-only browser analysis (D-147 observe_only) |
| `can_browser_mutate` | bool | Browser form fill / click (D-147 active_mutation) |
| `can_run_tests` | bool | Test execution capability |
| `can_reason_deep` | bool | Complex architectural / analytical reasoning |
| `can_low_cost_parallel` | bool | Lightweight parallel tasks (cheap model ok) |
| `can_tool_call` | bool | Function calling / MCP tool usage |
| `risk_tier_allowed` | enum | Maximum risk tier this profile may handle |

-----

## Execution Profiles (v1)

| Profile | Capabilities | Typical Provider | Typical Use |
|---|---|---|---|
| `analysis_browser_readonly` | browser_observe, reason_deep | Azure GPT | Usability audit, DOM analysis |
| `repo_reviewer_deep` | reason_deep, tool_call | Azure GPT / Anthropic | Architecture review, code review |
| `implementation_fast` | can_code, tool_call, can_run_tests | Azure GPT | Standard coding tasks |
| `implementation_verified` | can_code, tool_call, can_run_tests, reason_deep | Azure GPT | Complex implementation + verification |
| `low_cost_parallel_research` | can_low_cost_parallel, reason_deep | Azure GPT-mini / Ollama | Bulk research, summarization |

-----

## Selection Inputs

| Input | Source |
|---|---|
| `task_type` | Mission controller / user intent |
| `tools_required` | Task analysis / explicit request |
| `risk_tier` | D-128 risk classification |
| `browser_needed` | Task analysis |
| `code_mutation_needed` | Task analysis |
| `verification_needed` | Task analysis / policy rules |
| `provider_preference` | Operator override (optional) |

-----

## Selection Output

| Field | Description |
|---|---|
| `profile` | Execution profile name |
| `provider` | Selected provider |
| `model` | Selected model/deployment |
| `tool_set` | Allowed tools for this execution |
| `browser_mode` | none / observe_only / guided_repro / active_mutation |
| `verification_pack` | Required verification steps |
| `fallback_policy` | What happens on failure |
| `selection_reason` | Human-readable explanation |

-----

## v1 Components

| Component | Responsibility |
|---|---|
| `TaskClassifier` | Infers task type and required capabilities from mission input |
| `CapabilityResolver` | Maps required capabilities → eligible profiles |
| `ExecutionProfileResolver` | Selects profile + provider + tool set based on capabilities + routing policy |
| Static role fallback | If classifier fails or profile unknown → fall back to D-027 deterministic table |

-----

## Transition Strategy

```
Phase A: Shadow mode
  - Capability router runs in parallel with static routing
  - Both produce selection; static is used, capability is logged
  - Compare: would capability have chosen differently? Better?

Phase B: Capability-primary
  - Capability router drives selection
  - Static routing = fallback on classifier failure
  - Operator override always available

Phase C: Static sunset
  - Static routing removed from execution path
  - Role labels remain in UI only
  - Full capability-driven routing
```

-----

## Selection Quality Metrics

| Metric | Description |
|---|---|
| `task_completion_rate` | % tasks completed successfully per profile |
| `reroute_rate` | % tasks that triggered fallback/reroute |
| `human_override_rate` | % tasks where operator changed selection |
| `browser_session_success_rate` | % browser sessions that produced valid evidence |
| `verification_pass_rate` | % tasks that passed verification gate |
| `cost_per_successful_task` | Cost efficiency per profile |
| `latency_per_profile` | Average latency per execution profile |
| `provider_reliability` | Per-provider success rate |

-----

## Success Criteria (v1)

| Criterion | Target |
|---|---|
| Active execution profiles | ≥ 3 canlı |
| Static role fallback | Mevcut ve çalışıyor |
| Routing decisions traced | Her selection telemetry'de loglanıyor |
| Shadow mode comparison | ≥ 50 task karşılaştırma datası |
| Selection errors measurable | Override rate + reroute rate tracked |

-----

## Impacted Files

| File | Change |
|---|---|
| `agent/mission/task_classifier.py` | New |
| `agent/mission/capability_resolver.py` | New |
| `agent/mission/execution_profile.py` | New — profile definitions |
| `agent/mission/controller.py` | Integrate profile resolver into stage routing |
| `agent/mission/role_registry.py` | Add capability annotations to existing roles |
| `agent/mission/complexity_router.py` | Extend to use profiles (or replace in Phase C) |
| `agent/context/policy_telemetry.py` | Add selection telemetry events |
| `config/execution-profiles.yaml` | New — profile definitions config |
| Tests | New test module for classifier, resolver, profiles |

-----

## Supersedes / Modifies

| Decision | Impact |
|---|---|
| D-027 (Deterministic routing table) | **Modified** — deterministic table becomes fallback, not primary |
| D-030 (Same LLM differentiated by prompt+policy) | **Extended** — model selection now per-profile, not per-role |
| D-032 (4-tier complexity routing) | **Modified** — tiers become one input to capability resolver, not sole routing mechanism |

**Note:** These decisions are NOT deprecated. They remain valid as fallback behavior. Deprecation only in Phase C after capability routing is proven stable.

-----

## Trade-offs

| + | - |
|---|---|
| Task-aware routing — right tool for right job | Complexity increase: classifier + resolver + profiles |
| Multi-provider optimization enabled | Shadow mode period before full activation |
| Ölçülebilir seçim kalitesi | v1'de sınırlı profile sayısı (3-5) |
| Sabit roller kırılmaz (fallback) | İki routing path maintenance (shadow period) |
| Cost/latency optimization mümkün hale gelir | Classifier accuracy critical — yanlış sınıflama yanlış profile seçer |

-----

## Rollback / Reversal

- Phase A (shadow): Disable shadow logging → no impact
- Phase B (capability-primary): Set `routing.mode = static` → revert to D-027 table
- Phase C (static sunset): Re-enable static routing from config → instant rollback
- No irreversible change at any phase

-----

## Prerequisites

| Prerequisite | Why |
|---|---|
| D-146 frozen + implemented | ≥ 2 providers needed to test routing |
| D-147 v1 delivered | Browser observation data informs profile design |
| Provider selection telemetry active | Routing comparison requires measurement infrastructure |

-----

## Decision Lifecycle

| Date | Event |
|---|---|
| 2026-04-06 | Proposed by Claude + GPT cross-review |
| TBD | Frozen after D-146 implemented + D-147 v1 delivered |
