# S77 Kickoff — Azure OpenAI Provider Foundation

## Sprint Identity
- **Sprint:** S77
- **Phase:** 10
- **Previous:** S76 (closed)
- **Decision:** D-146 (frozen) — Azure OpenAI Primary Provider Adoption
- **Sprint class:** Product
- **Mutation budget:** 5

## Context
Azure OpenAI'ı primary provider olarak entegre ediyoruz. Mevcut provider'lar (OpenAI, Anthropic, Ollama) fallback olarak kalacak. Tüm provider'lar tek canonical request/response contract'a migrate edilecek. D-146 frozen — detaylar `docs/decisions/D-146-azure-primary-provider.md`'de.

## Kickoff Gate Checklist
Başlamadan önce doğrula:
- [ ] S76 closure_status = closed
- [ ] D-146 decision record `docs/decisions/` altına commit edilmiş
- [ ] DECISIONS.md'ye D-146 entry eklenmiş
- [ ] `docs/sprints/sprint-77/` klasörü oluşturulmuş
- [ ] `evidence/sprint-77/` klasörü oluşturulmuş
- [ ] `evidence/sprint-77/sprint-class.txt` → `product`
- [ ] Task breakdown dosyası sprint klasörüne kopyalanmış
- [ ] STATE.md → S77 in_progress
- [ ] NEXT.md güncellemiş

## Execution Order — SIRALI, ATLAMA YOK

### T-77.00: Azure tenant/deployment inventory + compatibility proof
**BU TASK TAMAMLANMADAN KOD YAZILMAZ.**

1. Operator'dan Azure bilgilerini al:
   - Endpoint URL
   - Deployment name
   - API version
   - Auth mode (api_key / entra_id)
   - Region
   - Model family (gpt-4o / gpt-4.1 / etc.)
2. Live smoke check yap:
   ```bash
   curl -X POST "https://<endpoint>/openai/deployments/<deployment>/chat/completions?api-version=<version>" \
     -H "Content-Type: application/json" \
     -H "api-key: <key>" \
     -d '{"messages":[{"role":"user","content":"ping"}],"max_tokens":5}'
   ```
3. Supported capabilities matrix oluştur (function calling, streaming, MCP, etc.)
4. Retirement date ve rate limit bilgisi kaydet
5. Artifact üret: `evidence/sprint-77/azure-deployment-inventory.md` + `evidence/sprint-77/azure-smoke-precheck.txt`

**Exit:** Inventory artifact var + deployment callable + capability matrix frozen.

---

### T-77.01: AzureDeploymentConfig + agent-config.json schema
- `AzureDeploymentConfig` dataclass oluştur
- `agent-config.json`'a `azure-openai` agent entry ekle
- `.env.example`'a Azure env vars ekle
- Config validation: eksik field → startup deny (D-013 pattern)
- Retirement date geçmişse → warning + retired flag

**Test:** Config load/validate unit tests
**Evidence:** pytest output

---

### T-77.02: AzureOpenAIProvider adapter + canonical contract migration
İKİ PARÇA:

**A) Azure adapter:**
- `agent/providers/azure_openai_provider.py` — AgentProvider'dan türer
- `openai.AzureOpenAI` SDK kullanır
- Error mapping: 404, 401, 429, timeout

**B) Canonical contract migration (TÜM PROVIDER'LAR):**
- `base.py`'da `TaskRequest` ve `ProviderResponse` tanımla
- GPTProvider, ClaudeProvider, OllamaProvider'ı da aynı contract'a migrate et
- Provider-specific branching provider layer dışında YASAK

**Test:** Her 4 provider için canonical contract unit test
**Evidence:** pytest output

---

### T-77.03: Provider factory + routing policy
- `factory.py`'a `azure-openai` branch ekle
- `ProviderRoutingPolicy` class: primary/fallback rules
- Kill switch: `azure.enabled=false` → fallback
- Unsupported tool → fallback triggered

**Fallback testleri ZORUNLU:**
- Azure → Anthropic fallback roundtrip
- Azure → OpenAI fallback roundtrip
- Azure disabled → fallback handles full workload
- Fallback path canonical contract kullanıyor (legacy değil)

**Evidence:** pytest output, routing decision log sample

---

### T-77.04: AzureHealthCheck + retirement guard
- Health check: endpoint liveness probe
- Retirement guard: 30 gün → warning, geçmiş → unhealthy → fallback
- `agents_api.py` ve `health_api.py`'a Azure ekle

**Evidence:** pytest output, health endpoint output

---

### T-77.05: ProviderSelectionTelemetry
- Her agent call'da: provider, reason, fallback_used logla
- `policy-telemetry.jsonl`'e yaz (D-129 pattern)

**Evidence:** pytest output, telemetry log sample

---

### T-77.06: Integration smoke test + evidence collection
- Azure'a gerçek call (text generation)
- Function call roundtrip
- Fallback test (Azure disabled)
- Health check integration test
- Evidence collect

**Evidence:** pytest-output.txt, integration-smoke.txt, telemetry-sample.jsonl

---

### T-77.MID: Mid review gate
- T-77.00 → T-77.03 DONE olmalı
- report.md hazırla
- GPT mid-review iste
- PASS olmadan T-77.04+ başlama

---

### T-77.07: Review gate + closure
- report.md tamamla
- GPT final review
- Retrospective yaz
- sprint-closure-check.sh çalıştır
- Evidence bundle doğrula

## Gates

### Gate A — Foundation PASS (sprint closure için gerekli)
- Config/schema validated
- Azure provider works (mock + unit)
- Health + retirement guard works
- Telemetry emits events
- Fallback chain works
- Canonical contract ALL providers'da aktif

### Gate B — Broad Default PASS (S78 prerequisite, S77 closure sonrası)
- Live Azure smoke passes
- Routing logs doğru provider seçiyor
- Kill switch verified
- Bu gate S77 closure'dan SONRA, S78 kickoff'tan ÖNCE

## Kurallar
- 1 task = 1 commit minimum
- Task DONE = 5/5 (code + test + evidence + notes + manifest)
- Implementation Notes drift → aynı gün güncelle
- Blocker → düzelt, sonra devam et
- Mutation budget: 5 (code/config mutations)
- Provider-specific branching provider layer DIŞINDA YASAK
